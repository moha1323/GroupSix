
import java.util.LinkedList;
import java.util.List;

public class Supplier {
	private String name;
	private String id;
	private List componentList = new LinkedList();

	public Supplier(String name) {
		this.name = name;
		this.id = generateId();
	}

	private String generateId() {
		return null;
	}

	public String getId() {
		return id;
	}

	public void addComponent(Component component) {
		componentList.add(component);
	}

}
