
public class Company {
	private ComponentList componentList;
	private SupplierList supplierList;
	private static Company company;

	private Company() {
		componentList = ComponentList.instance();
		supplierList = SupplierList.instance();
	}

	public static Company instance() {
		return company;
	}

	public void submitOrder(int quantity, String componentID, String supplierID) {

	}

	public void fulfillOrder(int orderNumber) {

	}

	public void addComponents(String name) {

	}

	public void addSupplier(String name) {

	}

	public void addComponentSupplier(String componentId, String supplierId) {

	}
}
