import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ComponentList {
	private List components = new LinkedList();
	private static ComponentList componentList;

	private ComponentList() {
	}

	public static ComponentList instance() {
		return componentList;
	}

	public Component search(String componentId) {
		for (Iterator iterator = components.iterator(); iterator.hasNext();) {
			Component component = (Component) iterator.next();
			if (component.getId().equals(componentId)) {
				return component;
			}
		}
		return null;
	}

	public boolean insertComponent(Component component) {
		components.add(component);
		return true;
	}
}
