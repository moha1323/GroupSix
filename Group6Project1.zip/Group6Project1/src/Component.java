
public class Component {
	private String name;
	private String id;
	private int stock;

	public Component(String name) {
		this.name = name;
		this.id = generateId();
	}

	private String generateId() {
		return null;
	}

	public String getId() {
		return id;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int units) {
		stock += units;
	}
}
