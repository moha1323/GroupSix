import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class SupplierList {
	private List suppliers = new LinkedList();
	private static SupplierList supplierList;

	private SupplierList() {
	}

	public static SupplierList instance() {
		return supplierList;
	}

	public Supplier search(String supplierId) {
		for (Iterator iterator = suppliers.iterator(); iterator.hasNext();) {
			Supplier supplier = (Supplier) iterator.next();
			if (supplier.getId().equals(supplierId)) {
				return supplier;
			}
		}
		return null;
	}

	public boolean insertSupplier(Supplier supplier) {
		suppliers.add(supplier);
		return true;
	}
}
